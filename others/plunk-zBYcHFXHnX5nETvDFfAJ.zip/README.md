# Anuglar Snap.js Template

Meant to be a starting point for plunks using [`angular-snap`](https://github.com/jtrussell/angular-snap.js)