var app = angular.module('plunker', ['snap']);

app.controller('MainCtrl', function($scope) {
  $scope.name = 'World';
});
